from app import create_app, db
from app.models import User
from werkzeug.security import generate_password_hash

app = create_app()

with app.app_context():
    db.create_all()
    admin_username = "admin"
    admin_password = "admin123"
    admin = User.query.filter_by(username=admin_username).first()
    if not admin:
        db.session.add(User(username=admin_username,
                            password=generate_password_hash(admin_password)))
        db.session.commit()
        print(f"Default admin user created -> username: {admin_username}, password: {admin_password}")
    else:
        print("Admin user already exists.")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
